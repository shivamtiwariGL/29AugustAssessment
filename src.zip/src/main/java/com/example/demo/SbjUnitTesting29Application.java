package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbjUnitTesting29Application {

	public static void main(String[] args) {
		SpringApplication.run(SbjUnitTesting29Application.class, args);
	}

}
